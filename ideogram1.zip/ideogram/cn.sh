#!/bin/bash

# Directory containing PNG images
input_directory="./"

# Loop through all PNG files in the directory
for png_file in "$input_directory"/*.png; do
  # Get the filename without the extension
  filename=$(basename "$png_file" .png)

  # Output JPG file
  output_file="$input_directory/$filename.jpg"

  # Convert PNG to JPG using ImageMagick's convert tool
  convert "$png_file" "$output_file"

  echo "Converted $png_file to $output_file"
done

